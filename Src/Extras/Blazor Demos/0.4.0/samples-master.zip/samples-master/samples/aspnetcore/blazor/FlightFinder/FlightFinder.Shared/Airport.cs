﻿namespace FlightFinder.Shared
{
    public class Airport
    {
        public string Code { get; set; }
        public string DisplayName { get; set; }
    }
}
