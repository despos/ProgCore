# Blazor samples

The samples in this directory are for [ASP.NET Core Blazor](https://github.com/aspnet/Blazor), an experimental .NET web framework using C#/Razor and HTML that runs in the browser with WebAssembly.

To learn more about Blazor, please see [documentation on its repo](https://github.com/aspnet/Blazor).

Please note that if you want to open Blazor projects in Visual Studio, you must have [Visual Studio 15.7 Preview 1](https://www.visualstudio.com/thank-you-downloading-visual-studio/?ch=pre&sku=Enterprise&rel=15) or later. You cannot open or build these projects in VS 15.6 or earlier.
