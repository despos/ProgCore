# Testing MVC applications in memory
This sample shows how to write an end to end test for MVC applications using TestServer.
For more details see https://blogs.msdn.microsoft.com/webdev/2017/12/07/testing-asp-net-core-mvc-web-apps-in-memory/
